package com.example.proyectev1.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.proyectev1.R
import kotlinx.android.synthetic.main.fragment_mail.*
import kotlinx.android.synthetic.main.fragment_multimedia.*

class MultimediaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_multimedia, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var cosa: Uri? = null
        selec.setOnClickListener(){
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type="*/*"
                Intent.EXTRA_ALLOW_MULTIPLE
            }
            startActivity(intent)
            cosa = intent.data
            compro2.text = "Archivo seleccionado"
        }

        val file: Uri = Uri.parse(cosa.toString())

        repro.setOnClickListener(){
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = file
            }
            startActivity(intent)
        }

    }
}