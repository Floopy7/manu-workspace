package com.example.proyectev1.fragments

import android.content.ContentResolver
import android.content.Intent
import android.os.Bundle
import android.service.autofill.CharSequenceTransformation
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.proyectev1.R
import kotlinx.android.synthetic.main.fragment_mail.*
import android.net.Uri

class MailFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_mail, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val document by lazy { mmrbd(context) }
        documento.setOnClickListener(){
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type="*/*"
                Intent.EXTRA_ALLOW_MULTIPLE
            }
            startActivity(intent)
            document = intent.data
            compro.setText("Uri del archivo:"+document.toString())
            val toast = Toast.makeText(context, "La uri del archivo es "+document.toString(), Toast.LENGTH_SHORT).show()

        }

        envio.setOnClickListener(){
            val intent2 = Intent (Intent.ACTION_SEND).apply {
                type="*/*"
                putExtra(Intent.EXTRA_EMAIL, email.text.toString())
                putExtra(Intent.EXTRA_SUBJECT, asunto.text.toString())
                putExtra(Intent.EXTRA_TEXT, cuerpo.text.toString())
                putExtra(Intent.EXTRA_STREAM, a)
            }

            startActivity(intent2)
        }

    }


}