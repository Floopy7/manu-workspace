package com.example.proyectev1.fragments

import android.app.Activity
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.service.autofill.CharSequenceTransformation
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.proyectev1.R
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_mail.*
import java.net.URI

class MailFragment : Fragment() {

    val REQUEST_IMAGE_GET = 1
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? = inflater.inflate(R.layout.fragment_mail, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        var fullUri: Uri? = null
        documento.setOnClickListener(){
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type="*/*"
                Intent.EXTRA_ALLOW_MULTIPLE
            }
            fullUri = startActivityForResult(intent, REQUEST_IMAGE_GET)

        }

        val cosa2: Uri = fullUri.parse(fullUri.toString())

        envio.setOnClickListener(){
            val list: Array<String> = arrayOf(email.text.toString())
            val asunto = asunto.text.toString();
            val cuerpo = cuerpo.text.toString();
            curreo (list, asunto, cuerpo, cosa2)
        }

    }
    private fun curreo (list: Array<String>, asunto: String, cuerpo: String, cosa: Uri) {

        val intent2 = Intent (Intent.ACTION_SEND).apply {
            type="*/*"
            putExtra(Intent.EXTRA_EMAIL, list)
            putExtra(Intent.EXTRA_SUBJECT, asunto)
            putExtra(Intent.EXTRA_TEXT, cuerpo)
            putExtra(Intent.EXTRA_STREAM, cosa)
        }

        startActivity(intent2)
    }
    internal final fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent): Uri?{
        var fullUri : Uri? = null
        if (requestCode == REQUEST_IMAGE_GET && resultCode == Activity.RESULT_OK) {
            fullUri= data.data
        }
        return fullUri
    }

    }